package org.cmcdistedu.cho;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
