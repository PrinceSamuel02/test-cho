import { Component, OnInit, SecurityContext } from '@angular/core';
import { ActivatedRoute, Router, NavigationExtras } from "@angular/router";
import { DomSanitizer, SafeResourceUrl } from "@angular/platform-browser";
import { File } from '@ionic-native/file/ngx';

import { Browser } from '@capacitor/browser';
import { Device } from '@capacitor/device';

@Component({
  selector: 'app-lm',
  templateUrl: './lm.page.html',
  styleUrls: ['./lm.page.scss'],
})

export class LmPage implements OnInit {
  mnum: string;
  murl: string;
  smurl: string;
  safeurl: SafeResourceUrl;
  dirlist: any = [];

  htmlSnippet: any;
  htmlData: any;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private sanitizer: DomSanitizer,
    private file: File,
  ) { }

  ngOnInit() {
    // this.route.queryParams.subscribe((params) => {
    //   if (this.router.getCurrentNavigation().extras.state) {
    //     console.log(this.router.getCurrentNavigation().extras.state);
    //   }
    // });

    this.route.queryParams.subscribe((params) => {
      if (this.router.getCurrentNavigation().extras.state) {
        console.log(this.router.getCurrentNavigation().extras.state);
        this.mnum = this.router.getCurrentNavigation().extras.state.moduleId;
        this.murl = this.router.getCurrentNavigation().extras.state.moduleUrl;
        // this.safeurl = this.sanitizer.bypassSecurityTrustUrl(this.murl);
        alert(this.murl);
        //this.safeurl = encodeURIComponent(this.murl);
      } else {
        //this.router.navigate(['menu/modules']);
      }
    });
  }
  async ionViewWillEnter() {
    //this.safeurl = this.sanitizer.bypassSecurityTrustResourceUrl("file:///D:/Users/arun/Desktop/google-translate.html");
    //this.safeurl = "assets/google-translate.html";
    // Browser.open({ url: this.safeurl }).then(res => {
    //   console.log(res);
    // }).catch(err => {
    //   console.log(err);
    // });
    //this.safeurl = this.sanitizer.bypassSecurityTrustResourceUrl(this.murl);
    //alert(this.safeurl);
    const info = await Device.getInfo();
    if (info.platform !== 'android' && info.platform !== 'ios') {
      //
    } else {
      alert(this.file.externalApplicationStorageDirectory + "modules/MyDownload_" + this.mnum + "/story.html");
      this.file.listDir(this.file.externalApplicationStorageDirectory, "modules").then(resdir => {
        this.dirlist = resdir;
        this.dirlist.forEach((d, index) => {
          if (d.name === "MyDownload_" + this.mnum) {
            alert(JSON.stringify(d));
            this.file.resolveLocalFilesystemUrl(d.nativeURL + "story.html").then(result => {
              alert(JSON.stringify(result));

            }).catch(err2 => {

            });
          }

        });

      }).catch(err => {

      });
    }
    //this.htmlData = this.file.externalApplicationStorageDirectory + "modules/MyDownload_"+this.mnum + "/story.html";

    //this.htmlSnippet = 'Template <script>alert("0wned")</script> <b>Syntax</b>';
  }
  // getSafeUrl() {
  //   console.log('getSafe murl: ', this.murl);
  //   return this.sanitizer.bypassSecurityTrustUrl(this.murl);
  // }

  goToModules() {
    let url = "/menu/modules";
    this.router.navigate([url]);
  }

}
