import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { EventService } from './../../services/event.service';
import { NavController } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-event-details',
  templateUrl: 'event-details.page.html',
  styleUrls: ['event-details.page.scss'],
})
export class EventDetailsPage implements OnInit {
  eventForm: FormGroup;
  id = null;

  constructor(private fb: FormBuilder, private route: ActivatedRoute, private eventService: EventService, private navCtrl: NavController) {
      
  }

  ngOnInit() {
    this.eventForm = this.fb.group({ 
      eventId: '', 
      eventType: '', 
      eventStartDateTime: '', 
      eventAttended: '', 
      eventUrl: '', 
      eventHostName: '', 
      eventSpeaker: '', 
      eventTopicName: '', 
      eventDescription: '', 
      eventDurationMinutes: '', 
      eventImageUrl: '',
  });

    this.id = this.route.snapshot.paramMap.get('id');
    if (this.id && this.id != 'null') {
      this.eventService.getEventById(this.id).subscribe(res => {
        this.eventForm.patchValue(res);
      });
    } else {
      this.id = null;
    }
  }

  submit() {
    if (this.id) {
      this.eventService.updateEventById(this.id, this.eventForm.value).then(res => {
        this.navCtrl.pop();
      });
    } else {
      this.eventService.addEvent(this.eventForm.value).then(res => {
        this.navCtrl.pop();
      });
    }
  }

  delete() {
    this.eventService.deleteEventById(this.id).then(res => {
      this.navCtrl.pop();
    });
  }
}
