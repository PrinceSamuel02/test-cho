import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModuleDetailsPageRoutingModule } from './module-details-routing.module';
import { ModuleDetailsPage } from './module-details.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule,
    ModuleDetailsPageRoutingModule
  ],
  declarations: [ModuleDetailsPage],
  providers: [],
  exports: []
})
export class ModuleDetailsPageModule { }
