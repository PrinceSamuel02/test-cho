import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ModuleService } from './../../services/module.service';
import { NavController } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-module-details',
  templateUrl: 'module-details.page.html',
  styleUrls: ['module-details.page.scss'],
})
export class ModuleDetailsPage implements OnInit {
  moduleForm: FormGroup;
  id = null;

  constructor(private fb: FormBuilder, private route: ActivatedRoute, private moduleService: ModuleService, private navCtrl: NavController) {
      
  }

  ngOnInit() {
    this.moduleForm = this.fb.group({ 
      moduleId: '', 
      moduleOrder: '', 
      moduleName: '', 
      moduleUrl: '', 
      moduleComplete: '', 
      moduleImageUrl: '',
  });

    this.id = this.route.snapshot.paramMap.get('id');
    if (this.id && this.id != 'null') {
      this.moduleService.getModuleById(this.id).subscribe(res => {
        this.moduleForm.patchValue(res);
      });
    } else {
      this.id = null;
    }
  }

  submit() {
    if (this.id) {
      this.moduleService.updateModuleById(this.id, this.moduleForm.value).then(res => {
        this.navCtrl.pop();
      });
    } else {
      this.moduleService.addModule(this.moduleForm.value).then(res => {
        this.navCtrl.pop();
      });
    }
  }

  delete() {
    this.moduleService.deleteModuleById(this.id).then(res => {
      this.navCtrl.pop();
    });
  }
}
