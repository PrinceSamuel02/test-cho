import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { NoteService } from './../../services/note.service';
import { Note } from './../../services/note';

@Component({
  selector: 'app-note',
  templateUrl: 'note.page.html',
  styleUrls: ['note.page.scss'],
})
export class NotePage implements OnInit {
  items: Observable<Note[]>;

  constructor(private noteService: NoteService) {
      
  }
  ngOnInit() {
    this.items = this.noteService.getNotes();
  }

}