import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ResourcesDetailsPageRoutingModule } from './resources-details-routing.module';
import { ResourcesDetailsPage } from './resources-details.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule,
    ResourcesDetailsPageRoutingModule
  ],
  declarations: [ResourcesDetailsPage],
  providers: [],
  exports: []
})
export class ResourcesDetailsPageModule { }
