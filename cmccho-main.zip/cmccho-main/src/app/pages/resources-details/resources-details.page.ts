import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ResourcesService } from './../../services/resources.service';
import { NavController } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-resources-details',
  templateUrl: 'resources-details.page.html',
  styleUrls: ['resources-details.page.scss'],
})
export class ResourcesDetailsPage implements OnInit {
  resourcesForm: FormGroup;
  id = null;

  constructor(private fb: FormBuilder, private route: ActivatedRoute, private resourcesService: ResourcesService, private navCtrl: NavController) {
      
  }

  ngOnInit() {
    this.resourcesForm = this.fb.group({ 
      resourceId: '', 
      resourceName: '', 
      resourceDescription: '', 
      resourceUrl: '', 
      resourceImageUrl: '', 
      resourceDisplayOrder: '', 
      resourceFavourited: '',
  });

    this.id = this.route.snapshot.paramMap.get('id');
    if (this.id && this.id != 'null') {
      this.resourcesService.getResourcesById(this.id).subscribe(res => {
        this.resourcesForm.patchValue(res);
      });
    } else {
      this.id = null;
    }
  }

  submit() {
    if (this.id) {
      this.resourcesService.updateResourcesById(this.id, this.resourcesForm.value).then(res => {
        this.navCtrl.pop();
      });
    } else {
      this.resourcesService.addResources(this.resourcesForm.value).then(res => {
        this.navCtrl.pop();
      });
    }
  }

  delete() {
    this.resourcesService.deleteResourcesById(this.id).then(res => {
      this.navCtrl.pop();
    });
  }
}
