import { Component, OnInit } from "@angular/core";
import { Observable } from "rxjs";
import { ModuleService } from "./../../services/module.service";
import { Module } from "./../../services/module";
import { ActivatedRoute, Router, NavigationExtras } from "@angular/router";

import { HttpClient } from "@angular/common/http";
import { AlertController, LoadingController, ToastController } from "@ionic/angular";
import { HTTP } from '@ionic-native/http/ngx';
import { File } from '@ionic-native/file/ngx';

import { PreviewAnyFile } from '@ionic-native/preview-any-file/ngx';
import { Zip } from '@ionic-native/zip/ngx';
import { Downloader, DownloadRequest, NotificationVisibility } from '@ionic-native/downloader/ngx';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';

import { Browser } from '@capacitor/browser';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Device } from '@capacitor/device';
import { Dialog } from '@capacitor/dialog';
import { Storage } from '@capacitor/storage';

@Component({
  selector: "app-module",
  templateUrl: "module.page.html",
  styleUrls: ["module.page.scss"],
})
export class ModulePage implements OnInit {
  //items: Observable<Module[]>;
  items: any = [];
  mimeType: string = "";
  fileUri: string = "";
  openerBtn: boolean = false;
  url: string = "";
  myurl: string = "";
  dirlist: any = [];
  user: any = {};
  showOpenButton: boolean = false;
  showDownloadButton: boolean = false;
  constructor(
    private moduleService: ModuleService,
    private router: Router,
    private route: ActivatedRoute,
    private http: HttpClient,
    private loader: LoadingController,
    private toast: ToastController,
    private HTTP: HTTP,
    private file: File,
    private previewAnyFile: PreviewAnyFile,
    private zip: Zip,
    private downloader: Downloader,
    private iab: InAppBrowser
  ) { }
  async ngOnInit() {
    this.items = [];
    //this.downloadFile("https://s3.ap-south-1.amazonaws.com/cho.cmcdistedu.org/Week_1/W1_1_Wellness_and_Illness/story.html");
    await Storage.get({ key: 'loggedUser' }).then(user => {
      if (user.value) {
        this.user = user.value;
        this.moduleService.getModules().subscribe(res => {
          res.forEach(async (ite, ind) => {
            ite.showOpenButton = false;
            //console.log(ite);
            const info = await Device.getInfo();
            if (info.platform !== 'android' && info.platform !== 'ios') {
              this.items.push(ite);
            } else {
              this.file.listDir(this.file.externalApplicationStorageDirectory, "modules").then(resdir => {
                this.dirlist = resdir;
                this.dirlist.forEach((d, index) => {
                  // alert(JSON.stringify(d));
                  // alert(d.name+" - "+"MyDownload_" + ite.moduleId);
                  if (d.name === "MyDownload_" + ite.moduleId) {
                    ite.showOpenButton = true;
                    ite.localUrl = d.nativeURL+"/story.html";
                    //alert("Foundthe match : "+d.name+" - "+"MyDownload_" + ite.moduleId);
                    //alert(JSON.stringify(ite));
                  }
                  if (index === this.dirlist.length - 1) {
                    this.items.push(ite);
                  }
                });

              }).catch(err => {
                // alert(err);
                // alert(JSON.stringify(err));
                console.log(err);
              });
            }

          });
        });
      } else {
        this.router.navigateByUrl('/login');
      }
    }).catch(err => {
      console.log(err);
    });

  }

  async ionViewWillEnter() {


  }

  goLM(moduleId: string, moduleUrl: string) {
    // let navigationExtras: NavigationExtras = {
    //   state: {
    //     moduleId: moduleId,
    //     moduleUrl: moduleUrl,
    //   },
    // };
    // console.log(navigationExtras);
    // let url = "/lm";
    // this.router.navigate([url], navigationExtras);
    Browser.open({ url: moduleUrl });
  }

  async downloadFile(id, url, zipurl) {

    this.loader.create({
      message: "Downloading Module " + id + "..."
    }).then(async (ele) => {
      ele.present();
      //var url = this.url;
      const info = await Device.getInfo();
      if (info.platform !== 'android' && info.platform !== 'ios') {
        if (zipurl) {
          let arr = zipurl.split('/');
          //var filename = arr[arr.length - 1];
          var name = arr[arr.length - 1];
          var filename = id + "_" + name;
          Browser.open({ url: zipurl }).then(res => {
            ele.dismiss();
          }).catch(err => {
            ele.dismiss();
          });
        } else {
          ele.dismiss();
          Dialog.confirm({
            title: 'Download',
            message: "Cannot find the zip file to download."
          });
        }

        // this.http.get(zipurl, { responseType: 'blob' })
        //   .subscribe((data) => {
        //     this.mimeType = data.type;
        //     console.log(this.mimeType);
        //     this.convertBlobToBase64(data, filename, ele);
        //   });
      } else {
        if (zipurl) {
          var request: DownloadRequest = {
            uri: zipurl,
            title: 'MyDownload_' + id,
            description: '',
            mimeType: '',
            visibleInDownloadsUi: true,
            notificationVisibility: NotificationVisibility.VisibleNotifyCompleted,
            destinationInExternalFilesDir: {
              dirType: '/Downloads',
              subPath: filename
            }
          };


          this.downloader.download(request).then(async (location: string) => {
            ele.dismiss();
            alert('File downloaded at:' + location);
            await this.file.createDir(this.file.externalApplicationStorageDirectory, 'modules', true).then(async res => {
              this.zip.unzip(location, this.file.externalApplicationStorageDirectory + "/modules/MyDownload_" + id, (progress) =>
                console.log('Unzipping, ' + Math.round((progress.loaded / progress.total) * 100) + '%'))
                .then((result) => {
                  this.file.removeFile(this.file.externalApplicationStorageDirectory, "files/Downloads-1");
                  this.file.removeDir(this.file.externalApplicationStorageDirectory, "files/Downloads");
                  if (result === 0) {
                    Dialog.confirm({
                      title: 'Downloaded',
                      message: "Downloaded to " + this.file.externalApplicationStorageDirectory + "modules/MyDownload_" + id
                    });
                  }
                  if (result === -1) alert('FAILED');
                });
            })
              .catch(async err => {
                ele.dismiss();
                Dialog.confirm({
                  title: 'Error Creating Directory',
                  message: 'modules Directory not created'
                });
              });
          })
            .catch((error: any) => console.error(error));

          // this.HTTP.sendRequest(zipurl, {
          //   method: 'get',
          //   data: {},
          //   headers: { observe: 'response', responseType: 'blob' },
          //   timeout: 5000
          // }).then(data => {
          //   this.mimeType = data.data.type;
          //   // this.convertBlobToBase64(data.data, filename, ele);
          //   this.saveBase64(filename, data.data, ele);
          // }).catch(error => {
          //   ele.dismiss();
          //   alert("error");
          //   alert(error);
          // });
        } else {
          ele.dismiss();
          Dialog.confirm({
            title: 'Download',
            message: "Cannot find the zip file to download."
          });
        }

      }
    })
  }
  // convertBlobToBase64(blob, filename, ele) {
  //   alert("convertBlobToBase64");
  //   alert(blob);
  //   var reader = new FileReader();
  //   reader.readAsDataURL(blob);
  //   var ref = this;
  //   reader.onloadend = function () {
  //     var base64data = reader.result;
  //     alert(filename);
  //     alert(base64data);
  //     ref.saveBase64(filename, base64data, ele);

  //   }
  // }

  // async saveBase64(filename, base64, ele) {
  //   console.log(base64);
  //   console.log(filename);
  //   const info = await Device.getInfo();
  //   if (info.platform !== 'android' && info.platform !== 'ios') {
  //     // await Filesystem.writeFile({
  //     //   path: filename,
  //     //   data: base64,
  //     //   directory: Directory.Documents,
  //     //   recursive: true
  //     // }).then(async (val) => {
  //     //   console.log(JSON.stringify(val));
  //     //   await Filesystem.readdir({
  //     //     path: filename,
  //     //     directory: Directory.Documents
  //     //   }).then(res => {
  //     //     console.log(res);
  //     //   }).catch(err => {
  //     //     console.log(err);
  //     //   });
  //     //   await Filesystem.getUri({
  //     //     path: filename,
  //     //     directory: Directory.Documents
  //     //   }).then((uri) => {
  //     //     this.fileUri = uri.uri;
  //     //     alert("File URL " + "file://" + this.fileUri);
  //     //     ele.dismiss();
  //     //     Browser.open({ url: "file://" + this.fileUri });
  //     //     this.toast.create({
  //     //       message: "File downloaded and saved!",
  //     //       duration: 3000
  //     //     }).then((ele1) => {
  //     //       ele1.present();
  //     //       this.openerBtn = true;
  //     //     });
  //     //   })
  //     // })
  //   } else {
  //     await this.file.createDir(this.file.externalApplicationStorageDirectory, 'modules', true).then(async res => {
  //       await this.file.writeFile(this.file.externalApplicationStorageDirectory + "modules", filename, base64, { replace: true, append: false })
  //         .then(async wres => {
  //           ele.dismiss();
  //           this.toast.create({
  //             message: "File downloaded and saved to " + this.myurl + "!",
  //             duration: 3000
  //           }).then((ele1) => {
  //             ele1.present();
  //             this.openerBtn = true;
  //           });

  //         })
  //         .catch(async werr => {
  //           Dialog.confirm({
  //             title: 'Error Writing File',
  //             message: "ERROR Writing file " + filename
  //           });

  //         });
  //     })
  //       .catch(async err => {
  //         Dialog.confirm({
  //           title: 'Error Creating Directory',
  //           message: 'modules Directory not created'
  //         });
  //       });

  //   }


  // }


  async openFile(id, url, zipurl) {
    // let arr = zipurl.split('/');
    // //var filename = arr[arr.length - 1];
    // var name = arr[arr.length - 1];
    // var filename = id + "_" + name;
    const info = await Device.getInfo();
    if (info.platform !== 'android' && info.platform !== 'ios') {
      //Browser.open({ url: "file:///D:/Users/arun/Downloads/TL1.1+Principles+of+Adult+Learning/story.html", windowName: "_blank" })
      // await Filesystem.getUri({
      //   path: filename,
      //   directory: Directory.Data
      // }).then((uri) => {
      //   this.fileUri = uri.uri;
      //   alert("File URL " + "file://" + this.fileUri);
      //   console.log("file://" + this.fileUri);
      //   Browser.open({ url: "file://" + this.fileUri })
      // });
    } else {
      this.myurl = this.file.externalApplicationStorageDirectory + "modules/MyDownload_" + id + "/story.html";
      try {


        this.file.listDir(this.file.externalApplicationStorageDirectory, "modules").then(resdir => {
          this.dirlist = resdir;
          this.dirlist.forEach((d, index) => {
            if (d.name === "MyDownload_" + id) {
              //alert(JSON.stringify(d));
              this.file.resolveLocalFilesystemUrl(d.nativeURL + "story.html").then(result => {
                alert(JSON.stringify(result));
                //window.open(d.nativeURL + "story.html", "_system");
                this.previewAnyFile.preview(result.nativeURL)
                .then((res: any) => console.log(res))
                .catch((error: any) => { 
                  console.log(error); 
                   
                });

                //   const browser = this.iab.create(d.nativeURL + "story.html");
                //   browser.on('loadstop').subscribe(event => {
                //     browser.insertCSS({ code: "body{color: red;" });
                //  });
                // let navigationExtras: NavigationExtras = {
                //   state: {
                //     moduleId: id,
                //     moduleUrl: result.nativeURL,
                //   },
                // };
                // console.log(navigationExtras);
                // let url = "/lm";
                // this.router.navigate([url], navigationExtras);

              })

            }
          });
        });
      } catch (e) {
        alert("error opening the local file");
        alert(e);
        alert(JSON.stringify(e));
      }
      // alert(this.myurl);
      // this.file.resolveDirectoryUrl(this.file.externalApplicationStorageDirectory).then(async res => {
      //   var result = res;
      //   this.myurl = result.nativeURL + 'modules/MyDownload_' + id + "/story.html";
      //   alert(this.myurl);
      //   let openfile = false;
      //   this.dirlist = [];
      // this.file.listDir(this.file.externalApplicationStorageDirectory, "modules").then(resdir => {
      //   this.dirlist = resdir;
      //   this.dirlist.forEach((d, index) => {
      //     if (d.name === "MyDownload_" + id) {
      //       openfile = true;
      // this.file.resolveDirectoryUrl(this.file.externalApplicationStorageDirectory).then(async res => {
      //   var result = res;
      //   alert(result.nativeURL);
      //   alert(result.nativeURL + "modules/MyDownload_" + id + "/story.html");
      //   // this.previewAnyFile.preview(result.nativeURL + "modules/MyDownload_" + id + "/story.html")
      //   //   .then((res: any) => console.log(res))
      //   //   .catch((error: any) => console.error(error));
      // }).catch(err => {
      //   console.log(err);
      // });
      // this.previewAnyFile.preview("file:///storage/emulated/0/Android/data/org.cmcdistedu.cho/modules/MyDownload_" + id + "/story.html")
      //   .then((res: any) => console.log(res))
      //   .catch((error: any) => console.log(error));
      // Browser.open({ url: this.myurl.replace("content", "file") }).then(resp => {
      //   alert("Success");
      // }).catch(errresp => {
      //   alert(errresp);
      // });

      //     }
      //     if (index === this.dirlist.length - 1) {
      //       if (openfile === false) {
      //         Dialog.confirm({
      //           title: 'Open file',
      //           message: "Download the file first to open."
      //         });
      //       }
      //     }
      //   });

      // }).catch(err => {
      //   console.log(err);
      // });

      // });

    }

  }
}
