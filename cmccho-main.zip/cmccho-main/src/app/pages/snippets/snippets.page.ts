import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-snippets',
  templateUrl: './snippets.page.html',
  styleUrls: ['./snippets.page.scss'],
})
export class SnippetsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
