import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SnippetsPage } from './snippets.page';

const routes: Routes = [
  {
    path: '',
    component: SnippetsPage
  },
  {
    path: 'simple-animation',
    loadChildren: () => import('../simple-animation/simple-animation.module').then( m => m.SimpleAnimationPageModule)
  },{
    path: 'hide-header',
    loadChildren: () => import('../hide-header/hide-header.module').then( m => m.HideHeaderPageModule)
  },{
    path: 'parallax-image',
    loadChildren: () => import('../parallax-image/parallax-image.module').then( m => m.ParallaxImagePageModule)
  },{
    path: 'modal-animation',
    loadChildren: () => import('../modal-animation/modal-animation.module').then( m => m.ModalAnimationPageModule)
  },{
    path: 'bottom-drawer',
    loadChildren: () => import('../bottom-drawer/bottom-drawer.module').then( m => m.BottomDrawerPageModule)
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SnippetsPageRoutingModule {}
