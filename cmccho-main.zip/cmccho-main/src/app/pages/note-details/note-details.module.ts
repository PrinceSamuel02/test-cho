import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NoteDetailsPageRoutingModule } from './note-details-routing.module';
import { NoteDetailsPage } from './note-details.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule,
    NoteDetailsPageRoutingModule
  ],
  declarations: [NoteDetailsPage],
  providers: [],
  exports: []
})
export class NoteDetailsPageModule { }
