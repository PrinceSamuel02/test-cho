import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { NoteService } from './../../services/note.service';
import { NavController } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-note-details',
  templateUrl: 'note-details.page.html',
  styleUrls: ['note-details.page.scss'],
})
export class NoteDetailsPage implements OnInit {
  noteForm: FormGroup;
  id = null;

  constructor(private fb: FormBuilder, private route: ActivatedRoute, private noteService: NoteService, private navCtrl: NavController) {
      
  }

  ngOnInit() {
    this.noteForm = this.fb.group({ 
      noteId: '', 
      noteName: '', 
      noteText: '', 
      noteArchived: '', 
      noteFavourited: '', 
      noteDisplayOrder: '',
  });

    this.id = this.route.snapshot.paramMap.get('id');
    if (this.id && this.id != 'null') {
      this.noteService.getNoteById(this.id).subscribe(res => {
        this.noteForm.patchValue(res);
      });
    } else {
      this.id = null;
    }
  }

  submit() {
    if (this.id) {
      this.noteService.updateNoteById(this.id, this.noteForm.value).then(res => {
        this.navCtrl.pop();
      });
    } else {
      this.noteService.addNote(this.noteForm.value).then(res => {
        this.navCtrl.pop();
      });
    }
  }

  delete() {
    this.noteService.deleteNoteById(this.id).then(res => {
      this.navCtrl.pop();
    });
  }
}
