import { enterAnimation, leaveAnimation } from './nav-animation';
import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { NavModalPage } from './nav-modal/nav-modal.page';

@Component({
  selector: 'app-modal-animation',
  templateUrl: './modal-animation.page.html',
  styleUrls: ['./modal-animation.page.scss'],
})
export class ModalAnimationPage implements OnInit {

  constructor(private modalController: ModalController) { }

  ngOnInit() {
  }

  async presentModal(animated?) {
    if (animated) {
      const modal = await this.modalController.create({
        component: NavModalPage,
        enterAnimation,
        leaveAnimation
      });
      await modal.present();
    } else {
      const modal = await this.modalController.create({
        component: NavModalPage,
      });
      await modal.present();
    }
  }

}
