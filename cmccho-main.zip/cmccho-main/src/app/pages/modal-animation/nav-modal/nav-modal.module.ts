import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { NavModalPageRoutingModule } from './nav-modal-routing.module';

import { NavModalPage } from './nav-modal.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    NavModalPageRoutingModule
  ],
  declarations: [NavModalPage]
})
export class NavModalPageModule {}
