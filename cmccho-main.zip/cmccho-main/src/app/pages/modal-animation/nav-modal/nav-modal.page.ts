import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-nav-modal',
  templateUrl: './nav-modal.page.html',
  styleUrls: ['./nav-modal.page.scss'],
})
export class NavModalPage implements OnInit {

  constructor(private modalController: ModalController) { }

  ngOnInit() {
  }

  close() {
    this.modalController.dismiss();
  }
}
