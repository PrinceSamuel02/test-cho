import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { NavModalPage } from './nav-modal.page';

describe('NavModalPage', () => {
  let component: NavModalPage;
  let fixture: ComponentFixture<NavModalPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NavModalPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(NavModalPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
