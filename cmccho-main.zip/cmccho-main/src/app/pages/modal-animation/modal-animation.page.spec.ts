import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ModalAnimationPage } from './modal-animation.page';

describe('ModalAnimationPage', () => {
  let component: ModalAnimationPage;
  let fixture: ComponentFixture<ModalAnimationPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalAnimationPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ModalAnimationPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
