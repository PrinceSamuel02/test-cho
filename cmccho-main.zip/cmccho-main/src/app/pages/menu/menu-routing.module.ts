import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MenuPage } from './menu.page';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/menu/start',
    pathMatch: 'full'
  },
  {
    path: '',
    component: MenuPage,
    children: [
        {
          path: 'start',
          loadChildren: () => import('../start/start.module').then( m => m.StartPageModule)
        },
        {
          path: 'start/snippets',
          loadChildren: () => import('../snippets/snippets.module').then( m => m.SnippetsPageModule)
        },
        { path: 'modules', loadChildren: () => import('../module/module.module').then( m => m.ModulePageModule)},
        { path: 'modules/:id', loadChildren: () => import('../module-details/module-details.module').then( m => m.ModuleDetailsPageModule)},
        { path: 'events', loadChildren: () => import('../event/event.module').then( m => m.EventPageModule)},
        { path: 'events/:id', loadChildren: () => import('../event-details/event-details.module').then( m => m.EventDetailsPageModule)},
        { path: 'notes', loadChildren: () => import('../note/note.module').then( m => m.NotePageModule)},
        { path: 'notes/:id', loadChildren: () => import('../note-details/note-details.module').then( m => m.NoteDetailsPageModule)},
        { path: 'resourceses', loadChildren: () => import('../resources/resources.module').then( m => m.ResourcesPageModule)},
        { path: 'resourceses/:id', loadChildren: () => import('../resources-details/resources-details.module').then( m => m.ResourcesDetailsPageModule)},
        { path: 'help', loadChildren: () => import('../help/help.module').then(m => m.HelpPageModule)},
        { path: 'about', loadChildren: () => import('../about/about.module').then(m => m.AboutPageModule)},
    ]
  }
];
  
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MenuPageRoutingModule {}
