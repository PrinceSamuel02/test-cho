import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SimpleAnimationPage } from './simple-animation.page';

const routes: Routes = [
  {
    path: '',
    component: SimpleAnimationPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SimpleAnimationPageRoutingModule {}
