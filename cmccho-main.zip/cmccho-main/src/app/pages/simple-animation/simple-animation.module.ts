import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SimpleAnimationPageRoutingModule } from './simple-animation-routing.module';

import { SimpleAnimationPage } from './simple-animation.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SimpleAnimationPageRoutingModule
  ],
  declarations: [SimpleAnimationPage]
})
export class SimpleAnimationPageModule {}
