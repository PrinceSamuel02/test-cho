import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { SimpleAnimationPage } from './simple-animation.page';

describe('SimpleAnimationPage', () => {
  let component: SimpleAnimationPage;
  let fixture: ComponentFixture<SimpleAnimationPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SimpleAnimationPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(SimpleAnimationPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
