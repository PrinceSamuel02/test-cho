import { Component, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { AnimationController, Animation } from '@ionic/angular';

@Component({
  selector: 'app-simple-animation',
  templateUrl: './simple-animation.page.html',
  styleUrls: ['./simple-animation.page.scss'],
})
export class SimpleAnimationPage implements AfterViewInit {
  anim: Animation;
  cardAnim: Animation;

  isPlaying = false;
  @ViewChild('square', { static: false }) square: ElementRef;
  @ViewChild('card', { static: false, read: ElementRef }) card: ElementRef;

  constructor(private animationCtrl: AnimationController) {}
 
  ngAfterViewInit() {
    this.anim = this.animationCtrl.create('myanim');
    this.anim
      .addElement(this.square.nativeElement)
      .duration(1500)
      .easing('ease-out')
      .iterations(Infinity)
      .fromTo('transform', 'translateX(0px)', 'translateX(300px)')
      .fromTo('opacity', 1, 0.2);

      this.cardAnim = this.animationCtrl.create('myanim');
      this.cardAnim
        .addElement(this.card.nativeElement)
        .duration(1500)
        .easing('ease-out')
        .iterations(Infinity)
        .fromTo('transform','translate3d(0,0,0)', 'translate3d(42px, 62px, 135px)')
        .fromTo('opacity', 1, 0.1);
  }

  toggleAnimation() {
    if (this.isPlaying) {
      this.anim.stop();
      this.cardAnim.stop();
    } else {
      this.anim.play();
      this.cardAnim.play();
    }
    this.isPlaying = !this.isPlaying;
  }
}
