import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hide-header',
  templateUrl: './hide-header.page.html',
  styleUrls: ['./hide-header.page.scss'],
})
export class HideHeaderPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
