import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { ResourcesService } from './../../services/resources.service';
import { Resources } from './../../services/resources';

@Component({
  selector: 'app-resources',
  templateUrl: 'resources.page.html',
  styleUrls: ['resources.page.scss'],
})
export class ResourcesPage implements OnInit {
  items: Observable<Resources[]>;

  constructor(private resourcesService: ResourcesService) {
      
  }
  ngOnInit() {
    this.items = this.resourcesService.getResourcess();
  }

}