import { Component, OnInit, ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-bottom-drawer',
  templateUrl: './bottom-drawer.page.html',
  styleUrls: ['./bottom-drawer.page.scss'],
})
export class BottomDrawerPage implements OnInit {

  backdropVisible = false;
 
  constructor(private changeDetectorRef: ChangeDetectorRef) { }
 
  ngOnInit() {
  }

  toggleBackdrop(isVisible) {
    this.backdropVisible = isVisible;
    this.changeDetectorRef.detectChanges();
  }
}
