import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { EventService } from './../../services/event.service';
import { Event } from './../../services/event';

@Component({
  selector: 'app-event',
  templateUrl: 'event.page.html',
  styleUrls: ['event.page.scss'],
})
export class EventPage implements OnInit {
  items: Observable<Event[]>;

  constructor(private eventService: EventService) {
      
  }
  ngOnInit() {
    this.items = this.eventService.getEvents();
  }

}