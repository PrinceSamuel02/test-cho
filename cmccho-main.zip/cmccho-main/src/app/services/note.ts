export interface Note {
  noteId: string;
  noteName: string;
  noteText: string;
  noteArchived: boolean;
  noteFavourited: boolean;
  noteDisplayOrder: number;
  createdAt: any;
}
  