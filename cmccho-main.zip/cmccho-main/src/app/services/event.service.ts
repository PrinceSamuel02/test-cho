import { Event } from './event';
import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/firestore';
import { take } from 'rxjs/operators';
import { Observable } from 'rxjs';
import firebase from 'firebase/app';
import 'firebase/auth';

@Injectable({
    providedIn: 'root'
})
export class EventService {
    eventCollection: AngularFirestoreCollection <Event>;

    constructor(private afs: AngularFirestore) {
        this.eventCollection = this.afs.collection<Event>('events');
    }

    addEvent(item: Event) {
        item.createdAt = firebase.firestore.FieldValue.serverTimestamp();
        return this.eventCollection.add(item);
    }

    updateEventById(id, item: Event) {
        return this.eventCollection.doc(id).set(item);
    }

    getEvents(): Observable<Event[]> {
        return this.eventCollection.valueChanges({idField: 'id'});
    }

    getEventById(id): Observable<Event>{
        return this.eventCollection.doc<Event>(id).valueChanges().pipe(take(1));
    }

    deleteEventById(id) {
        return this.afs.doc<Event>(`events/${id}`).delete();
    }
}

