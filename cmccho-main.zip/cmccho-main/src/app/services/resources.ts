export interface Resources {
  resourceId: string;
  resourceName: string;
  resourceDescription: string;
  resourceUrl: string;
  resourceImageUrl: string;
  resourceDisplayOrder: number;
  resourceFavourited: boolean;
  createdAt: any;
}
  