import { Resources } from './resources';
import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/firestore';
import { take } from 'rxjs/operators';
import { Observable } from 'rxjs';
import firebase from 'firebase/app';
import 'firebase/auth';

@Injectable({
    providedIn: 'root'
})
export class ResourcesService {
    resourcesCollection: AngularFirestoreCollection <Resources>;

    constructor(private afs: AngularFirestore) {
        this.resourcesCollection = this.afs.collection<Resources>('resourceses');
    }

    addResources(item: Resources) {
        item.createdAt = firebase.firestore.FieldValue.serverTimestamp();
        return this.resourcesCollection.add(item);
    }

    updateResourcesById(id, item: Resources) {
        return this.resourcesCollection.doc(id).set(item);
    }

    getResourcess(): Observable<Resources[]> {
        return this.resourcesCollection.valueChanges({idField: 'id'});
    }

    getResourcesById(id): Observable<Resources>{
        return this.resourcesCollection.doc<Resources>(id).valueChanges().pipe(take(1));
    }

    deleteResourcesById(id) {
        return this.afs.doc<Resources>(`resourceses/${id}`).delete();
    }
}

