export interface Event {
  eventId: string;
  eventType: string;
  eventStartDateTime: Date;
  eventAttended: boolean;
  eventUrl: string;
  eventHostName: string;
  eventSpeaker: string;
  eventTopicName: string;
  eventDescription: string;
  eventDurationMinutes: number;
  eventImageUrl: string;
  createdAt: any;
}
  