import { Note } from './note';
import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/firestore';
import { take } from 'rxjs/operators';
import { Observable } from 'rxjs';
import firebase from 'firebase/app';
import 'firebase/auth';

@Injectable({
    providedIn: 'root'
})
export class NoteService {
    noteCollection: AngularFirestoreCollection <Note>;

    constructor(private afs: AngularFirestore) {
        this.noteCollection = this.afs.collection<Note>('notes');
    }

    addNote(item: Note) {
        item.createdAt = firebase.firestore.FieldValue.serverTimestamp();
        return this.noteCollection.add(item);
    }

    updateNoteById(id, item: Note) {
        return this.noteCollection.doc(id).set(item);
    }

    getNotes(): Observable<Note[]> {
        return this.noteCollection.valueChanges({idField: 'id'});
    }

    getNoteById(id): Observable<Note>{
        return this.noteCollection.doc<Note>(id).valueChanges().pipe(take(1));
    }

    deleteNoteById(id) {
        return this.afs.doc<Note>(`notes/${id}`).delete();
    }
}

