export interface Module {
  localUrl: string;
  moduleId: string;
  moduleOrder: number;
  moduleName: string;
  moduleUrl: string;
  moduleZipUrl: string;
  moduleComplete: boolean;
  moduleImageUrl: string;
  createdAt: any;
  showOpenButton: boolean;
}
  