import { Module } from './module';
import { Injectable } from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/firestore';
import { take } from 'rxjs/operators';
import { Observable } from 'rxjs';
import firebase from 'firebase/app';
import 'firebase/auth';

@Injectable({
    providedIn: 'root'
})
export class ModuleService {
    moduleCollection: AngularFirestoreCollection <Module>;

    constructor(private afs: AngularFirestore) {
        this.moduleCollection = this.afs.collection<Module>('modules');
    }

    addModule(item: Module) {
        item.createdAt = firebase.firestore.FieldValue.serverTimestamp();
        return this.moduleCollection.add(item);
    }

    updateModuleById(id, item: Module) {
        return this.moduleCollection.doc(id).set(item);
    }

    getModules(): Observable<Module[]> {
        return this.moduleCollection.valueChanges({idField: 'id'});
    }

    getModuleById(id): Observable<Module>{
        return this.moduleCollection.doc<Module>(id).valueChanges().pipe(take(1));
    }

    deleteModuleById(id) {
        return this.afs.doc<Module>(`modules/${id}`).delete();
    }
}

