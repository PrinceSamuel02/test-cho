export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyApvTizPS1bWQLS_TJYNAhmVKNiOHp089c',
    authDomain: 'cmccho-6eb2c.firebaseapp.com',
    databaseURL: 'undefined',
    projectId: 'cmccho-6eb2c',
    storageBucket: 'cmccho-6eb2c.appspot.com',
    messagingSenderId: '576093630806',
    appId: '1:576093630806:web:124959ab29f10e1a58a6f7',
    measurementId: 'G-ZKQSHFM9ZJ',
  }
};
