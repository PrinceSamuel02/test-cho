# CHO CMC App


## Quick start

```shell
npm install
ionic serve
```

## Backend
- Firebase
